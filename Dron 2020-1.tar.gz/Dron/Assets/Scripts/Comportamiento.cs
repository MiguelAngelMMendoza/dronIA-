﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Comportamiento : MonoBehaviour {

	private Sensores sensor;
	private Actuadores actuador;
	private Rigidbody rb;
	private enum Estado {Detenerse=0, AvanzarAlFrente=1, RotarDerecha=2, Girar90GradosDerecha=3};
	private Estado estadoActual; // Usar un único estado actual que dicta qué acción realizar
	public float anguloDeseado; // Auxiliar para guardar el ángulo de rotación en el eje Y

	void Start(){
		sensor = GetComponent<Sensores>();
		actuador = GetComponent<Actuadores>();
		rb = GetComponent<Rigidbody>();
		estadoActual = Estado.AvanzarAlFrente;
		anguloDeseado = rb.rotation.eulerAngles.y;
	}

	void FixedUpdate () {
		if(sensor.Bateria() <= 0)
			return;

		// Aquí se determinan las acciones que va a realizar el dron, según la lista de estados
		switch(estadoActual){
			// CASO PARA DETENERSE
			case(Estado.Detenerse):
			Debug.Log("Estado detenerse");
				actuador.Flotar();
				actuador.Detener();
				break;
			// CASO PARA AVANZAR AL FRENTE
			// Si se desea rotar al dron en una cierta cantidad de grados,
			// por ejemplo 90 grados, es buena idea conservar el angulo deseado
			// y permitir que otro estado se encargue de hacer el giro.
			case(Estado.AvanzarAlFrente):
				if(sensor.FrenteAPared()){
					Debug.Log("Estado avanzar al frente");
					actuador.Adelante();
					anguloDeseado = CalcularAnguloDeseado(rb.rotation.eulerAngles.y);
					estadoActual = Estado.Girar90GradosDerecha;
					actuador.Adelante();

				}
				else { // Si no hay pared al frente, continuar avanzando
					actuador.Adelante();
				}
				break;
			// CASO PARA ROTAR DE MANERA CONTINUA
			// Gira levemente y cambia al estado AvanzarAlFrente si no tiene pared al frente
			// Es un movimiento continuo que gira y avanza casi al mismo tiempo
			case(Estado.RotarDerecha):
			Debug.Log("Estado rotar derecha");
				actuador.Esquiva();
				actuador.Adelante();
				if(!sensor.FrenteAPared() | !sensor.CercaDePared() | sensor.TocandoPared()){
					estadoActual = Estado.AvanzarAlFrente;
				}else {
					Debug.Log("El else XD");
					actuador.Esquiva();
					actuador.Adelante();
					estadoActual = Estado.RotarDerecha;
				}
				break;
			// CASO PARA ROTAR EN UNA CANTIDAD DETERMINADA DE GRADOS
			// Previamente se ha guardado la cantidad de grados deseada para rotar,
			// así que el dron no avanzará hasta haber completado el giro deseado
			// Es un movimiento más controlado pues se ha detenido, gira y después avanza.
			case(Estado.Girar90GradosDerecha):
			Debug.Log("Estado girar 90 grados");
				actuador.Esquiva();
				actuador.Adelante();
				estadoActual = Estado.RotarDerecha;
				// La segunda comprobación es necesaria para el caso en que 360 grados se convierte en 0 grados:
				if(rb.rotation.eulerAngles.y >= anguloDeseado && rb.rotation.eulerAngles.y < anguloDeseado + 90.0f)
					estadoActual = Estado.AvanzarAlFrente;
				break;
		}
	}

	// Auxiliar para establecer angulo de rotación deseado.
	// Se hace manualmente porque es común que la rotación del dron en cada frame
	// puede no ser exacta en 0, 90, 180, 270 ó 360 grados.
	// Nota: 360 grados se convierte en 0 grados.
	float CalcularAnguloDeseado(float anguloActual){
		if(anguloActual >= 0.0f && anguloActual < 90.0f)
			return 90.0f;
		if(anguloActual >= 90.0f && anguloActual < 180.0f)
			return 180.0f;
		if(anguloActual >= 180.0f && anguloActual < 270.0f)
			return 270.0f;
		if(anguloActual >= 270.0f)
			return 0.0f;
		return 0.0f;
	}
}
